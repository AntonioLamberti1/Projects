package connector;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class Connector {

    private final String PATHDRIVER = "com.mysql.cj.jdbc.Driver";
    private final String URLDB = "jdbc:mysql://localhost:3306/e_commerce";
    private final String USERDBMS = "root";
    private final String PASSDBMS = "root";
    //mi avvalgo del polimorfismo per interfaccia
    //in quanto Connection e' un'interfaccia.
    private Connection conn = null;
    private static Connector instance = null;

    //questo metodo deve ritornare al DAO un oggetto Connection
    //per aprire e chiudere la connessione al DB per ogni operazione
    //crud
    public synchronized Connection openConnection() {
        try {															
            //riga suscettibile a ClassNotFoundException
            Class.forName(PATHDRIVER); 
            //riga suscettibile a SQLException
            conn = DriverManager.getConnection(URLDB, USERDBMS, PASSDBMS);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }

    private Connector() {}                     // 	
    										   //
    public static Connector getInstance() {	   //
        if(instance == null) {				   //   Pattern Singleton
            instance = new Connector();		   //
        }									   //
        return instance; 					   //
    }                                          //

}