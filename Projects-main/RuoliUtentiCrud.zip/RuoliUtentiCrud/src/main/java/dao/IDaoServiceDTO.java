package dao;

import java.util.List;

import model.DTO;

public interface IDaoServiceDTO {

	public List<DTO> letturaView();
}
