package model;

import java.sql.Date;
import java.util.Objects;

public class DTO {

	private int id;
	private String username, email, password, nome, cognome, cf;
	private Date dataNascita;
	private double stipendio;
	private String nomeRuolo, descrizione;
	
	public DTO() {}
	
	public DTO(int id, String username, 
			String email, String password, 
			String nome, String cognome, String cf,
			Date dataNascita, double stipendio, 
			String nomeRuolo, String descrizione) {
		
		this.id = id;
		this.username = username;
		this.email = email;
		this.password = password;
		this.nome = nome;
		this.cognome = cognome;
		this.cf = cf;
		this.dataNascita = dataNascita;
		this.stipendio = stipendio;
		this.nomeRuolo = nomeRuolo;		
		this.descrizione = descrizione;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return cognome;
	}

	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getCf() {
		return cf;
	}

	public void setCf(String cf) {
		this.cf = cf;
	}

	public Date getDataNascita() {
		return dataNascita;
	}

	public void setDataNascita(Date dataNascita) {
		this.dataNascita = dataNascita;
	}

	public double getStipendio() {
		return stipendio;
	}

	public void setStipendio(double stipendio) {
		this.stipendio = stipendio;
	}

	public String getNomeRuolo() {
		return nomeRuolo;
	}

	public void setNomeRuolo(String nomeRuolo) {
		this.nomeRuolo = nomeRuolo;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	@Override
	public String toString() {
		return id+";"+username+";"+email+";"+password+";"+nome+";"+cognome+";"+cf+";"+dataNascita+";"+stipendio+";"+nomeRuolo+";"+descrizione;
		}

	@Override
	public int hashCode() {
		return Objects.hash(cf, cognome, dataNascita, descrizione, email, id, nome, nomeRuolo, password, stipendio,
				username);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DTO other = (DTO) obj;
		return Objects.equals(cf, other.cf) && Objects.equals(cognome, other.cognome)
				&& Objects.equals(dataNascita, other.dataNascita) && Objects.equals(descrizione, other.descrizione)
				&& Objects.equals(email, other.email) && id == other.id && Objects.equals(nome, other.nome)
				&& Objects.equals(nomeRuolo, other.nomeRuolo) && Objects.equals(password, other.password)
				&& Double.doubleToLongBits(stipendio) == Double.doubleToLongBits(other.stipendio)
				&& Objects.equals(username, other.username);
	}
	
		
}
