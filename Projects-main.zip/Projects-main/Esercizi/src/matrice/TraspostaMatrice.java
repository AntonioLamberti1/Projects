package matrice;

public class TraspostaMatrice {
	public static void main (String[] args) {
		int[][] matrice = { };
	}
}
