package daoService;

import java.util.List;

public interface IDaoService<E>{
	public boolean insert(E element);
	public E findById(int id);
	public List<E> findAll();
	public boolean update(E element);
	public boolean delete(int id);
	
}
