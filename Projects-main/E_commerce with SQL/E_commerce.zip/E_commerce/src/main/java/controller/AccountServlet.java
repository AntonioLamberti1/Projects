package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import daoService.DaoAccount;
import daoService.DaoDTOAccount;
import daoService.DaoRuolo;
import model.Account;

@WebServlet("/AccountServlet")
public class AccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	DaoAccount daoA = new DaoAccount();
	DaoRuolo daoR = new DaoRuolo();
	DaoDTOAccount daoD = new DaoDTOAccount();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		 
		int scelta = Integer.parseInt(request.getParameter("scelta"));
		switch (scelta) {
		case 1:// lettura singola
			Account a = daoA.findById(Integer.parseInt(request.getParameter("id")));
			request.setAttribute("listaRuoli", daoR.findAll());
			request.setAttribute("account", a);
			request.getRequestDispatcher("modificaAccount.jsp").forward(request, response);;
			break;
		case 2:// lettura totale
			request.setAttribute("listaAccounts", daoD.findAll());
			request.getRequestDispatcher("visualizzaAccounts.jsp").forward(request, response);;
//			request.setAttribute("listaAccounts", daoA.findAll());
//			request.getRequestDispatcher("visualizzaAccounts.jsp").forward(request, response);
			break;
		case 3:// eliminazione
			daoA.delete(Integer.parseInt(request.getParameter("id")));
			response.sendRedirect("AccountServlet?scelta=2");
			break;
		case 6:
			request.setAttribute("listaRuoli", daoR.findAll());
			request.getRequestDispatcher("InserireAccount.jsp").forward(request, response);
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int scelta = Integer.parseInt(request.getParameter("scelta"));
		Account a = new Account();
		a.setEmail(request.getParameter("email"));
		a.setUsername(request.getParameter("username"));
		a.setPassword(request.getParameter("password"));
		if (request.getParameter("id_ruolo") != null) {
			a.setId_ruolo(Integer.parseInt(request.getParameter("id_ruolo")));
		}
		switch (scelta) {
		case 4:// inserimento
			daoA.insert(a);
			response.sendRedirect("AccountServlet?scelta=2");
			break;
		case 5://  modifica
			a.setId(Integer.parseInt(request.getParameter("id")));
			daoA.update(a);
			response.sendRedirect("AccountServlet?scelta=2");
			break;
		}

	}

}
