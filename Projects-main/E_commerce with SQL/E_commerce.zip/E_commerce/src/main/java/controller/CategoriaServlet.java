package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import daoService.DaoCategoria;
import model.Categoria;

@WebServlet("/CategoriaServlet")
public class CategoriaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	DaoCategoria daoC = new DaoCategoria();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		 
		int scelta = Integer.parseInt(request.getParameter("scelta"));
		switch (scelta) {
		case 1:// lettura singola
			Categoria c = daoC.findById(Integer.parseInt(request.getParameter("id")));
			request.setAttribute("categoria", c);
			request.getRequestDispatcher("modificaCategoria.jsp").forward(request, response);;
			break;
		case 2:// lettura totale
			request.setAttribute("listaCategorie", daoC.findAll());
			request.getRequestDispatcher("visualizzaCategorie.jsp").forward(request, response);;
//			request.setAttribute("listaAccounts", daoA.findAll());
//			request.getRequestDispatcher("visualizzaAccounts.jsp").forward(request, response);
			break;
		case 3:// eliminazione
			daoC.delete(Integer.parseInt(request.getParameter("id")));
			response.sendRedirect("CategoriaServlet?scelta=2");
			break;
		case 6:
			request.getRequestDispatcher("InserireCategoria.jsp").forward(request, response);
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int scelta = Integer.parseInt(request.getParameter("scelta"));
		Categoria c = new Categoria();
		c.setNomeCategoria(request.getParameter("nome_categoria"));
		switch (scelta) {
		case 4:// inserimento
			daoC.insert(c);
			response.sendRedirect("CategoriaServlet?scelta=2");
			break;
		case 5://  modifica
			c.setId(Integer.parseInt(request.getParameter("id")));
			daoC.update(c);
			response.sendRedirect("CategoriaServlet?scelta=2");
			break;
		}

	}

}
