package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import daoService.DaoMarca;
import model.Marca;

@WebServlet("/MarcaServlet")
public class MarcaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	DaoMarca daoM = new DaoMarca();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		 
		int scelta = Integer.parseInt(request.getParameter("scelta"));
		switch (scelta) {
		case 1:// lettura singola
			Marca m = daoM.findById(Integer.parseInt(request.getParameter("id")));
			request.setAttribute("marca", m);
			request.getRequestDispatcher("modificaMarca.jsp").forward(request, response);;
			break;
		case 2:// lettura totale
			request.setAttribute("listaMarche", daoM.findAll());
			request.getRequestDispatcher("visualizzaMarche.jsp").forward(request, response);;
			break;
		case 3:// eliminazione
			daoM.delete(Integer.parseInt(request.getParameter("id")));
			response.sendRedirect("MarcaServlet?scelta=2");
			break;
		case 6:
			request.getRequestDispatcher("InserireMarca.jsp").forward(request, response);
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int scelta = Integer.parseInt(request.getParameter("scelta"));
		Marca m = new Marca();
		m.setNomeMarca(request.getParameter("nome_marca"));
		switch (scelta) {
		case 4:// inserimento
			daoM.insert(m);
			response.sendRedirect("MarcaServlet?scelta=2");
			break;
		case 5://  modifica
			m.setId(Integer.parseInt(request.getParameter("id")));
			daoM.update(m);
			response.sendRedirect("MarcaServlet?scelta=2");
			break;
		}

	}

}
