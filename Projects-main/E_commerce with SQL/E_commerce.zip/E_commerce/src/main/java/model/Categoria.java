package model;

import java.util.Objects;

public class Categoria {

	private int id;
	private String nomeCategoria;
	
	public void setId(int id) {
		this.id=id;
		}
	
	public int getId() {
		return this.id;
	}
	
	public void setNomeCategoria(String nomeCategoria) {
		this.nomeCategoria = nomeCategoria;
	}
	
	public String getNomeCategoria() {
		return this.nomeCategoria;
	}
	
	public String toString() {
		return id + "," + nomeCategoria;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, nomeCategoria);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Categoria other = (Categoria) obj;
		return id == other.id && Objects.equals(nomeCategoria, other.nomeCategoria);
	}
	
}