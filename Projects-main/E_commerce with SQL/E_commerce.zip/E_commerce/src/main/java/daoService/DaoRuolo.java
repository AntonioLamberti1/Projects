package daoService;

import static connector.Connector.getInstance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Ruolo;

public class DaoRuolo implements IDaoService<Ruolo> {

	@Override
	public boolean insert(Ruolo r) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		String commandSQL = "Insert into ruoli(nome_ruolo) values(?)";
		try {
			ps = conn.prepareStatement(commandSQL);
			ps.setString(1, r.getNomeRuolo());
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}

	@Override
	public Ruolo findById(int id) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Ruolo r = null;
		String commandSQL = "select * from ruoli where id=?";
		try {
			ps = conn.prepareStatement(commandSQL);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			if (rs.next()) {
				r = new Ruolo();
				r.setId(rs.getInt("id"));
				r.setNomeRuolo(rs.getString("nome_ruolo"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return r;
	}

	@Override
	public List<Ruolo> findAll() {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Ruolo r = null;
		List<Ruolo> ruoli = new ArrayList<>();
		String commandSQL = "select * from ruoli";
		try {
			ps = conn.prepareStatement(commandSQL);
			rs = ps.executeQuery();
			while (rs.next()) {
				r = new Ruolo();
				r.setId(rs.getInt("id"));
				r.setNomeRuolo(rs.getString("nome_ruolo"));
				ruoli.add(r);
			}
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return ruoli;
	}

	@Override
	public boolean update(Ruolo r) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		String commandSQL = "update ruoli set nome_ruolo=? where id=?";
		try {
			ps = conn.prepareStatement(commandSQL);
			ps.setString(1, r.getNomeRuolo());
			ps.setInt(2, r.getId());
			ps.execute();
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}

	@Override
	public boolean delete(int id) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		String commandSQL = "delete from ruoli where id = ? ";
		try {
			ps = conn.prepareStatement(commandSQL);
			ps.setInt(1, id);
			ps.execute();
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}
	
	public boolean insertDefault() {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String commandSQL = "select id from ruoli";
		try {
			ps = conn.prepareStatement(commandSQL);
			rs = ps.executeQuery();
			if (!rs.next()) {
				ps.close();
				commandSQL = "insert into ruoli(nome_ruolo) values('superAdmin'),('admin'),"
						+ "('cliente')";
				ps = conn.prepareStatement(commandSQL);
				ps.execute();
			}
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}

}
