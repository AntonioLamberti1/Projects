package daoService;

import static connector.Connector.getInstance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.DTOProduct;

public class DaoDTOProduct {
	
	public List<DTOProduct> findAll(){
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		DTOProduct dto = null;
		List<DTOProduct> dtos = new ArrayList<>();
		String commandSQL = "select * from v_pr_mar_cat_id";
		try {
			ps = conn.prepareStatement(commandSQL);
			rs = ps.executeQuery();
			while (rs.next()) {
				dto = new DTOProduct();
				dto.setId(rs.getInt("id"));
				dto.setNomeP(rs.getString("nomeP"));
				dto.setNomeC(rs.getString("nomeC"));
				dto.setNomeM(rs.getString("nomeM"));
				dto.setPrezzo(rs.getDouble("prezzo"));
				dto.setQuantita(rs.getInt("quantita"));
				dtos.add(dto);
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return dtos;
	}
}
