package daoService;

import static connector.Connector.getInstance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Utente;

public class DaoUtente implements IDaoService<Utente>{
	@Override
	public boolean insert(Utente u) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String commandSQL = "select max(id) as massimo from accounts";
			try {
				ps = conn.prepareStatement(commandSQL);
				rs = ps.executeQuery();
				if(rs.next()) {
					int id_account = rs.getInt("massimo");
					ps.close();
					commandSQL = "Insert into utenti(nome, cognome, codice_fiscale, cap, provincia,"
							+ "citta, via, numero_civico, id_account) "
							+ "values(?,?,?,?,?,?,?,?,?)";
					ps = conn.prepareStatement(commandSQL);
					ps.setString(1, u.getNome());
					ps.setString(2, u.getCognome());
					ps.setString(3, u.getCodiceFiscale());
					ps.setString(4, u.getCap());
					ps.setString(5, u.getProvincia());
					ps.setString(6, u.getCitta());
					ps.setString(7, u.getVia());
					ps.setInt(8, u.getNumeroCivico());
					ps.setInt(9, id_account);
					ps.execute();
				}
			}catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					ps.close();
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
					return false;
				}
			}
			return true;
		}
//		try {
//			ps = conn.prepareStatement(commandSQL);
//			ps.setString(1, u.getNome());
//			ps.setString(2, u.getCognome());
//			ps.setString(3, u.getCodiceFiscale());
//			ps.setString(4, u.getCap());
//			ps.setString(5, u.getProvincia());
//			ps.setString(6, u.getCitta());
//			ps.setString(7, u.getVia());
//			ps.setInt(8, u.getNumeroCivico());
//			ps.setInt(9, u.getId());
//			ps.execute();

	@Override
	public Utente findById(int id) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Utente u = null;
		String commandSQL = "select * from utenti where id=?";
		try {
			ps = conn.prepareStatement(commandSQL);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			if (rs.next()) {
				u = new Utente();
				u.setId(rs.getInt("id"));
				u.setNome(rs.getString("nome"));
				u.setCognome(rs.getString("cognome"));
				u.setCodiceFiscale(rs.getString("codice_fiscale"));
				u.setCap(rs.getString("cap"));
				u.setProvincia(rs.getString("provincia"));
				u.setCitta(rs.getString("citta"));
				u.setVia(rs.getString("via"));
				u.setNumeroCivico(rs.getInt("numero_civico"));
				u.setIdAccount(rs.getInt("id_account"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return u;
	}

	@Override
	public List<Utente> findAll() {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Utente u = null;
		List<Utente> utenti = new ArrayList<>();
		String commandSQL = "select * from utenti";
		try {
			ps = conn.prepareStatement(commandSQL);
			rs = ps.executeQuery();
			while (rs.next()) {
				u = new Utente();
				u.setId(rs.getInt("id"));
				u.setNome(rs.getString("nome"));
				u.setCognome(rs.getString("cognome"));
				u.setCodiceFiscale(rs.getString("codice_fiscale"));
				u.setCap(rs.getString("cap"));
				u.setProvincia(rs.getString("provincia"));
				u.setCitta(rs.getString("citta"));
				u.setVia(rs.getString("via"));
				u.setNumeroCivico(rs.getInt("numero_civico"));
				u.setIdAccount(rs.getInt("id_account"));
				utenti.add(u);
			}
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return utenti;
	}

	@Override
	public boolean update(Utente u) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		String commandSQL = "update utenti set nome=?, cognome=?, codice_fiscale=?,"
				+ "cap=?, provincia=?, citta=?, via=?, numero_civico=? "
				+ " where id=?";
		try {
			ps = conn.prepareStatement(commandSQL);
			ps.setString(1, u.getNome());
			ps.setString(2, u.getCognome());
			ps.setString(3, u.getCodiceFiscale());
			ps.setString(4, u.getCap());
			ps.setString(5, u.getProvincia());
			ps.setString(6, u.getCitta());
			ps.setString(7, u.getVia());
			ps.setInt(8, u.getNumeroCivico());
			ps.setInt(9, u.getId());
			ps.execute();
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}

	@Override
	public boolean delete(int id) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		String commandSQL = "delete from utenti where id = ? ";
		try {
			ps = conn.prepareStatement(commandSQL);
			ps.setInt(1, id);
			ps.execute();
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}
	
	public boolean insertDefault() {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String commandSQL = "select id from utenti";
		try {
			ps = conn.prepareStatement(commandSQL);
			rs = ps.executeQuery();
			if (!rs.next()) {
				ps.close();
				commandSQL = "Insert into utenti(nome, cognome, codice_fiscale, cap, provincia, citta, via, numero_civico, id_account) "
						+ "values ('Unknown','Unknown','asdfghjklzxcvbnm','asdfg','NA','Unknown','Unknown',12345,1),"
						+ "('Unknown','Unknown','asdfghjklzxcvbnm','asdfg','NA','Unknown','Unknown',12345,2),"
						+ "('Unknown','Unknown','asdfghjklzxcvbnm','asdfg','SA','Unknown','Unknown',12345,3),"
						+ "('Unknown','Unknown','asdfghjklzxcvbnm','asdfg','NA','Unknown','Unknown',12345,4)";
				ps = conn.prepareStatement(commandSQL);
				ps.execute();
			}
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}
	
}
