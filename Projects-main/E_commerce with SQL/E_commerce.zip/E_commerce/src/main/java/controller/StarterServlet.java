package controller;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import daoService.DaoAccount;
import daoService.DaoCategoria;
import daoService.DaoMarca;
import daoService.DaoRuolo;
import daoService.DaoUtente;


@WebServlet("")
public class StarterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     public void init(ServletConfig config) {
    	 
    	 DaoRuolo daoR = new DaoRuolo();
    	 ServletContext applicationRuolo = config.getServletContext();
    	 applicationRuolo.setAttribute("daoRuolo", daoR);
    	 daoR.insertDefault();
    	 
    	 DaoAccount daoA = new DaoAccount();
    	 ServletContext applicationAccount = config.getServletContext();
    	 applicationAccount.setAttribute("daoAccount", daoA);
    	 daoA.insertDefault();
    	 
    	 DaoUtente daoU = new DaoUtente();
    	 ServletContext applicationUtente = config.getServletContext();
    	 applicationUtente.setAttribute("daoUtente", daoU);
    	 daoU.insertDefault();
    	 
    	 DaoMarca daoM = new DaoMarca();
    	 ServletContext applicationMarca= config.getServletContext();
    	 applicationMarca.setAttribute("daoMarca",daoM);
    	 daoM.insertDefault();
    	 
    	 DaoCategoria daoC = new DaoCategoria();
    	 ServletContext applicationCategoria = config.getServletContext();
    	 applicationCategoria.setAttribute("daoCategoria",daoC);
    	 daoC.insertDefault();
    	 
     }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("Home.html");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doGet(request, response);
	}

}
