package model;

import java.util.Objects;

public class Marca {
	
	private int id;
	private String nomeMarca;
	
	public void setId(int id) {
		this.id=id;
		}
	
	public int getId() {
		return this.id;
	}
	
	public void setNomeMarca(String nomeMarca) {
		this.nomeMarca = nomeMarca;
	}
	
	public String getNomeMarca() {
		return this.nomeMarca;
	}
	
	public String toString() {
		return id + "," + nomeMarca;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, nomeMarca);
	};

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Marca other = (Marca) obj;
		return id == other.id && Objects.equals(nomeMarca, other.nomeMarca);
	}
	
}