package model;

import java.util.Objects;

public class Prodotto {
	
	private int id;
	private String nomeProdotto;
	private double prezzo;
	private int quantita;
	private int idMarca;
	private int idCategoria;
	
	public void setId(int id) {
		this.id=id;
		}
	
	public int getId() {
		return this.id;
	}
	
	public void setNomeProdotto(String nomeProdotto) {
		this.nomeProdotto = nomeProdotto;
	}
	
	public String getNomeProdotto() {
		return this.nomeProdotto;
	}
	
	public int getQuantita() {
		return this.quantita;
	}
	
	public void setQuantita(int quantita) {
		this.quantita = quantita;
	}
	
	public double getPrezzo() {
		return this.prezzo;
	}
	
	public void setPrezzo(Double prezzo) {
		this.prezzo=prezzo;
	}
	
	public void setIdMarca(int idMarca) {
		this.idMarca = idMarca;
	}
	
	public int getIdMarca() {
		return this.idMarca;
	}
	
	public void setIdCategoria(int idCategoria) {
		this.idCategoria = idCategoria;
	}
	
	public int getIdCategoria() {
		return this.idCategoria;
	}

	public Prodotto() {}
	
	public Prodotto(int id, String nomeProdotto, double prezzo, int quantita, int idMarca, int idCategoria) {
		this.id = id;
		this.nomeProdotto = nomeProdotto;
		this.prezzo = prezzo;
		this.quantita = quantita;
		this.idMarca = idMarca;
		this.idCategoria = idCategoria;
	}
	
	@Override
	public String toString() {
		return id + "," + nomeProdotto + "," + prezzo + "," + quantita + "," + idMarca + "," + idCategoria;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, idCategoria, idMarca, nomeProdotto, prezzo, quantita);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Prodotto other = (Prodotto) obj;
		return id == other.id && idCategoria == other.idCategoria && idMarca == other.idMarca
				&& Objects.equals(nomeProdotto, other.nomeProdotto)
				&& Double.doubleToLongBits(prezzo) == Double.doubleToLongBits(other.prezzo)
				&& quantita == other.quantita;
	}
	
}