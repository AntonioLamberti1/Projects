package controller;

import java.io.IOException;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.DaoServiceDTO;
import model.DTO;


@WebServlet("/DTOServlet")
public class DTOServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DaoServiceDTO newDao = new DaoServiceDTO();
//		newDao.letturaView();
		List<DTO> listaFiltrata = new ArrayList<>();
		int pagina = 1;
		if(request.getParameter("pagina") != null) {
			pagina = Integer.parseInt(request.getParameter("pagina"));
		}
		int nPagine = 0;
		int totElementi = newDao.letturaView().size();
		int nVisualizzati = 3; 
		int offset = 0; 
		int limit = 0; 
		if(totElementi % nVisualizzati != 0)
			nPagine = (totElementi / nVisualizzati)+1; 
		else
			nPagine = (totElementi / nVisualizzati);
		if(pagina == 0) { 
			pagina = 1;
		}
		else if(pagina > nPagine) { 
			pagina = nPagine;
		}
		offset = (pagina - 1) * nVisualizzati;
		limit = offset + nVisualizzati;
		for(int i = offset; i < limit && i < newDao.letturaView().size(); i++) {
			listaFiltrata.add(newDao.letturaView().get(i)); 
		}
		request.setAttribute("view", listaFiltrata);
		request.setAttribute("nPagine", nPagine);
		request.setAttribute("pagina", pagina);
		request.getRequestDispatcher("tabellaDTO.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
