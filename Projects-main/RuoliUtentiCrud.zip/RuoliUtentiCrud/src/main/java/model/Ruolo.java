package model;

import java.util.Objects;

public class Ruolo {

	private int id;
	private String nome, descrizione;
	
	public Ruolo() {}
	
	public Ruolo(int id, String nome, String descrizione) {
		this.id = id;
		this.nome = nome;
		this.descrizione = descrizione;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
		
	@Override
	public String toString() {
		return id + ";" + nome + ";" + descrizione;
	}

	@Override
	public int hashCode() {
		return Objects.hash(descrizione, id, nome);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Ruolo other = (Ruolo) obj;
		return Objects.equals(descrizione, other.descrizione) && id == other.id && Objects.equals(nome, other.nome);
	}
	
	
	
}
