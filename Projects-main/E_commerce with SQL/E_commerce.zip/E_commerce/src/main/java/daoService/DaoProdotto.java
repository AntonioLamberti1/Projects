package daoService;

import static connector.Connector.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Prodotto;

public class DaoProdotto implements IDaoService<Prodotto> {
	@Override
	public boolean insert(Prodotto p) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		String comandoSQL = "insert into prodotti (nomeP,prezzo,quantita,id_marca,id_categoria)" + "values(?,?,?,?,?)";
		try {
			ps = conn.prepareStatement(comandoSQL);
			ps.setString(1, p.getNomeProdotto());
			ps.setDouble(2, p.getPrezzo());
			ps.setInt(3, p.getQuantita());
			ps.setInt(4, p.getIdMarca());
			ps.setInt(5, p.getIdCategoria());
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();

			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	};

	@Override
	public Prodotto findById(int id) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Prodotto p = null;
		String comandoSQL = "select * from prodotti where id=?";
		try {
			ps = conn.prepareStatement(comandoSQL);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			if (rs.next()) {
				p = new Prodotto();
				p.setId(rs.getInt("id"));
				p.setNomeProdotto(rs.getString("nomeP"));
				p.setPrezzo(rs.getDouble("prezzo"));
				p.setQuantita(rs.getInt("quantita"));
				p.setIdMarca(rs.getInt("id_marca"));
				p.setIdCategoria(rs.getInt("id_categoria"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				return null;
			}
		}
		return p;

	};

	@Override
	public List<Prodotto> findAll() {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Prodotto p = null;
		List<Prodotto> listaProdotti = new ArrayList<>();
		String comandoSQL = "select * from prodotti";
		try {
			ps = conn.prepareStatement(comandoSQL);
			rs = ps.executeQuery();
			while (rs.next()) {
				p = new Prodotto();
				p.setId(rs.getInt("id"));
				p.setNomeProdotto(rs.getString("nomeP"));
				p.setPrezzo(rs.getDouble("prezzo"));
				p.setQuantita(rs.getInt("quantita"));
				p.setIdMarca(rs.getInt("id_marca"));
				p.setIdCategoria(rs.getInt("id_categoria"));
				listaProdotti.add(p);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return listaProdotti;

	};

	@Override
	public boolean update(Prodotto modificato) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		String comandoSQL = "update prodotti set nomeP=?,prezzo=?,quantita=?,id_marca=?,id_categoria=? where id = ?";
		try {
			ps = conn.prepareStatement(comandoSQL);
			ps.setInt(6, modificato.getId());
			ps.setString(1, modificato.getNomeProdotto());
			ps.setDouble(2, modificato.getPrezzo());
			ps.setInt(3, modificato.getQuantita());
			ps.setInt(4, modificato.getIdMarca());
			ps.setInt(5, modificato.getIdCategoria());
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();

			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	};

	@Override
	public boolean delete(int id) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		String comandoSQL = "delete from prodotti where id = ?";
		try {
			ps = conn.prepareStatement(comandoSQL);
			ps.setInt(1, id);
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();

			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	};
}
