package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Ruolo;
import static connettore.Connettore.*;

public class DaoServiceRuoli implements IDaoServiceRuoli{

	@Override
	public boolean inserimento(Ruolo r) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		String comandoSQL = "insert into ruoli(nome,descrizione) values (?,?)";
		try {
			ps = conn.prepareStatement(comandoSQL);
			ps.setString(1, r.getNome());
			ps.setString(2, r.getDescrizione());
			ps.execute();
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch(SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}

	@Override
	public Ruolo letturaSingola(int id) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Ruolo r = null;
		String comandoSQL = "select * from ruoli where id=?";
		try {
			ps = conn.prepareStatement(comandoSQL);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			if(rs.next()) {
				r = new Ruolo();
				r.setId(rs.getInt("id"));
				r.setNome(rs.getString("nome"));
				r.setDescrizione(rs.getString("descrizione"));
				}
			} catch(SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					ps.close();
					conn.close();
				} catch(SQLException e) {
					e.printStackTrace();
					return null;
			}
		}
		return r;
	}

	@Override
	public List<Ruolo> lettura() {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Ruolo r = null;
		List<Ruolo> ruoli = new ArrayList<Ruolo>();
		String comandoSQL = "select * from ruoli";
		try {
			ps = conn.prepareStatement(comandoSQL);
			rs = ps.executeQuery();
			while(rs.next()) {
				r = new Ruolo();
				r.setId(rs.getInt("id"));
				r.setNome(rs.getString("nome"));
				r.setDescrizione(rs.getString("descrizione"));
				ruoli.add(r);
				}
			} catch(SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					ps.close();
					conn.close();
				} catch(SQLException e) {
					e.printStackTrace();
					return null;
				}
			}
		return ruoli;
	}

	@Override
	public boolean modifica(Ruolo r) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		String comandoSQL = "update ruoli set nome=?, descrizione=? where id=?";
		try {
			ps = conn.prepareStatement(comandoSQL);
			ps.setString(1, r.getNome());
			ps.setString(2, r.getDescrizione());
			ps.setInt(3, r.getId());
			ps.execute();
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch(SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}

	@Override
	public boolean elimina(int id) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		String comandoSQL = "delete from ruoli where id=?";
		try {
			ps = conn.prepareStatement(comandoSQL);
			ps.setInt(1, id);
			ps.execute();
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch(SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}

	@Override
	public void inserimentoFabbrica() {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String comandoSQL = "select nome from ruoli";
		try {
			ps = conn.prepareStatement(comandoSQL);
			rs = ps.executeQuery();
			if(!rs.next()) {
				ps.close();
				comandoSQL = "insert into ruoli (nome,descrizione) values"
							+ "('admin','utente di fabbrica con permessi'),"
							+ "('guest','utente di fabbrica senza permessi')";
//				comandoSQL = "insert into ruoli(nome) values ('admin'),('guest')";
				ps = conn.prepareStatement(comandoSQL);
				ps.execute();
			}
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch(SQLException e) {
				e.printStackTrace();
			}
		}
		
	}

}
