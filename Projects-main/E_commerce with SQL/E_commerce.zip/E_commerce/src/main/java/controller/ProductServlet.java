package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import daoService.DaoCategoria;
import daoService.DaoDTOProduct;
import daoService.DaoMarca;
import daoService.DaoProdotto;
import model.Prodotto;

@WebServlet("/ProductServlet")
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	DaoProdotto daoP = new DaoProdotto();
	DaoDTOProduct daoDTO = new DaoDTOProduct();
	DaoCategoria daoC = new DaoCategoria();
	DaoMarca daoM = new DaoMarca();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		 
		int scelta = Integer.parseInt(request.getParameter("scelta"));
		switch (scelta) {
		case 1:// lettura singola
			Prodotto p = daoP.findById(Integer.parseInt(request.getParameter("id")));
			request.setAttribute("listaMarche", daoM.findAll());
			request.setAttribute("listaCategorie", daoC.findAll());
			request.setAttribute("prodotto", p);
			request.getRequestDispatcher("modificaProdotto.jsp").forward(request, response);
			break;
		case 2:// lettura totale
			request.setAttribute("listaProdotti", daoDTO.findAll());
			request.getRequestDispatcher("visualizzaProdotti.jsp").forward(request, response);
			break;
		case 3:// eliminazione
			daoP.delete(Integer.parseInt(request.getParameter("id")));
			response.sendRedirect("ProductServlet?scelta=2");
			break;
		case 6:
			request.setAttribute("listaMarche", daoM.findAll());
			request.setAttribute("listaCategorie", daoC.findAll());
			request.getRequestDispatcher("InserireProdotto.jsp").forward(request, response);
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int scelta = Integer.parseInt(request.getParameter("scelta"));
		Prodotto p = new Prodotto();
		p.setNomeProdotto(request.getParameter("nomeP"));
		if (request.getParameter("id_marca") != null) {
			p.setIdMarca(Integer.parseInt(request.getParameter("id_marca")));
		}
		if (request.getParameter("id_categoria") != null) {
			p.setIdCategoria(Integer.parseInt(request.getParameter("id_categoria")));
		}
		p.setPrezzo(Double.parseDouble(request.getParameter("prezzo")));
		p.setQuantita(Integer.parseInt(request.getParameter("quantita")));
		switch (scelta) {
		case 4:// inserimento
			daoP.insert(p);
			response.sendRedirect("ProductServlet?scelta=2");
			break;
		case 5://  modifica
			p.setId(Integer.parseInt(request.getParameter("id")));
			daoP.update(p);
			response.sendRedirect("ProductServlet?scelta=2");
			break;
		}

	}

}
