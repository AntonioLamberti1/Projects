package validation;

public interface IValidation {

	public String controlloNonVuoto(String valore, String campo);
	public String controlloLettere(String valore, String campo);
	public String controlloLunghezza(String valore, String campo);
	public String controlloLunghezza(String stringa, String campo, int maxLength);
	public String controlloCodiceFiscale(String valore, String campo);
	public String controlloEmail(String valore);
	public String controlloNumerico(String valore, String campo);
	public String controlloNumericoDouble(String valore, String campo);
	public String controlloPassword(String valore, String campo);
	public String controlloData(String valore, String campo);
	
}
