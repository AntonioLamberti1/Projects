package validation;

public class Validation implements IValidation{

	@Override
	public String controlloNonVuoto(String valore, String campo) {
		String controllo = "";
		if(valore.equals(null)) { 
			controllo = campo + " è obbligatorio";
		}else if(valore.equals("")) { 
			controllo = campo + " è obbligatorio";
		}
		return controllo;
	}

	@Override
	public String controlloLettere(String valore, String campo) {
		String controllo = controlloNonVuoto(valore, campo);
		if(controllo.equals("") && !valore.matches("^\\D+$")){
			controllo = campo + " accetta solo lettere";
		}
		return controllo;
	}

	@Override
	public String controlloLunghezza(String valore, String campo) {
		String controllo = controlloNonVuoto(valore, campo);
		if(controllo.equals("")){
			if(!valore.matches("^\\D+$")) {
				controllo = campo + " accetta solo lettere";
			}
			if(valore.length()>1) {
				controllo = campo + " accetta almeno due lettere";
			}
			if(valore.length()<=12) {
				controllo = campo + " accetta non più di 12 lettere";
			}
		}
		return controllo;
	}

	@Override
	public String controlloLunghezza(String stringa, String campo, int maxLength) {
		String controllo = controlloNonVuoto(stringa, campo);
		if(controllo.equals("") && stringa.length() > maxLength) {
			controllo = campo + " ha superato i " + maxLength + " caratteri.";
		}
		return controllo;
	}

	@Override
	public String controlloCodiceFiscale(String valore, String campo) {
		String controllo = controlloNonVuoto(valore, campo);
		int length = valore.length();
		if(controllo.equals("")) {
			if(!valore.matches("^[A-Z]{6}\\d{2}[A-Z]\\d{2}[A-Z]\\d{3}[A-Z]$")) {
				controllo = campo + " è composto in modo errato.";
			}else if(length<16 || length>16){
				controllo = campo + " troppo breve/lungo (16 caratteri).";
			}
		}
		return controllo;
	}

	@Override
	public String controlloEmail(String valore) {
		String campo = "Email";
		String controllo = controlloLunghezza(valore,campo,40); 
		if(controllo.equals("") && !valore.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$")){
			controllo = "Composizione email errata.";
		}
		return controllo;
	}

	@Override
	public String controlloNumerico(String valore, String campo) {
		String controllo = controlloNonVuoto(valore, campo);
		if(controllo.equals("") && !valore.matches("^\\d+$")){
			controllo = campo + " accetta solo numeri.";
		}
		return controllo;
	}

	@Override
	public String controlloNumericoDouble(String valore, String campo) {
		String controllo = controlloNonVuoto(valore, campo);
		if(controllo.equals("") && !valore.matches("^(\\d{1,6})?([.]\\d{0,2})?$")){
			controllo = campo + " accetta solo numeri.";
		}
		return controllo;
	}

	@Override
	public String controlloPassword(String valore, String campo) {
		String controllo = controlloNonVuoto(valore, campo);
		if(controllo.equals("") && !valore.matches("^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).{8,}$")){
			controllo = campo + " non rispetta la regola.";
		}
		return controllo;
	}

	@Override
	public String controlloData(String valore, String campo) {
		String controllo = controlloNonVuoto(valore, campo);
		if(controllo.equals("") && !valore.matches("^(\\d{4})-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$")){
			controllo = campo + " la data non rispetta il formato.";
		}
		return controllo;
	}

	
}
