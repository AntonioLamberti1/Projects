import psycopg2

def menu():
    print("1) Inserimento")
    print("2) Modifica")
    print("3) Cancellazione")
    print("4) Trova")
    print("5) Visualizzazione")
    print("6) Esci")
    
def continua():
    continua = input("Premi Invio per continuare")
    print()

# database connection con database = test
connection = psycopg2.connect(
        host = "localhost", port = "5433", database = "test2",
        user= "postgres", password = "admin") #user e passwd informazioni di default
cursor = connection.cursor()
etichette= ["Id= ", "Nome= ", "Cognome= "]      #per abbellire
scelta = 0
trovato = False
trovati = []
while scelta != 6:
    menu()
    scelta = int(input("Inserire un numero da 1 a 6: "))
    if scelta == 1:
        print ("-----   Inserimento     -----")
        print ("1) Inserire una tabella ")
        print ("2) Inserire valori in una tabella specifica ")
        cerca = int(input("Inserire un numero da 1 a 2: "))
        if cerca == 1:
            tabella = input("Inserire il nome della tabella: ")
            cursor.execute("Create table "+tabella+"("      
                           "id serial primary key, "
                           "nome varchar(30) not null, "
                           "cognome varchar(30) "
                           ")")
            connection.commit()
            print ("Inserimento della tabella eseguita con successo")
        elif cerca == 2:
            tabella = input("Inserire la tabella dove inserire i dati: ")
            nome = input("Inserire il nome da inserire: ")
            cognome = input("Inserire il cognome da inserire: ")
            cursor.execute("Insert into "+tabella+
                           "(nome, cognome) values ('"+nome+"','"+cognome+"')")
            connection.commit() #Apply changes to the database
            print ("Inserimento conseguito con successo")
        continua()
    if scelta == 4 or scelta == 3 or scelta == 2:
        if scelta == 4:
            print ("-----   Trova   -----")
        elif scelta == 3:
            print ("-----   Cancellazione   -----")
        else:
            print ("-----   Modifica       -----")
        print ("1) Cerca per Id")
        print ("2) Cerca per nome e cognome")
        cerca = int(input("Inserire un numero da 1 a 2: "))
        if cerca == 1:
            idDaCercare = int(input("Inserire l'id da cercare: "))
            tabella = input("Inserire la tabella da cercare: ")
            cursor.execute("SELECT * FROM "+tabella)
            rows = cursor.fetchall()
            for x in range (len(rows)):
                if idDaCercare == rows[x][0]:
                    indice = x
                    trovato = True
                    for y in range (len(rows[indice])):
                        print (etichette[y]+str(rows[indice][y]))
                    break  
            if trovato:
                if scelta == 3:
                    risposta = input("Vuoi cancellare? (si/no): ")
                    if risposta == "si":
                        indice = idDaCercare
                        delete_query =("Delete from "+tabella+" where id= %s")
                        cursor.execute(delete_query, indice)
                        print ("Cancellazione eseguita con successo")
                elif scelta == 2:
                    appValore = ""
                    risposta = input("Vuoi modificare? (si/no): ")
                    if risposta == "si":
                        indice = idDaCercare
                        nome = input("Inserire nuovo nome: ")
                        cognome = input("Inserire nuovo cognome: ")
                        update_query = ("update "+tabella+
                                        " set nome= '"+nome+"', cognome= '"+cognome+"' where id= %s")
                        cursor.execute(update_query, indice)
                        #oppure fare un for che cambi nome e cognome 
                        print ("Modifica eseguita con successo")
                    else:
                        print ("Modifica annullata")
            else:
                print ("Id non trovato")
        elif cerca == 2:
            nomeDaCercare = input("Inserire nome da cercare: ")
            cognomeDaCercare = input("Inserire cognome da cercare: ")
            tabella = input("Inserire la tabella da cercare: ")
            cursor.execute("SELECT * FROM "+tabella)
            rows = cursor.fetchall()
            for x in range(len(rows)):
                if nomeDaCercare == rows[x][1] and cognomeDaCercare == rows[x][2]:
                    trovati.append(rows[x])
                    for y in range (len(rows[x])):
                        print (etichette[y] + str(rows[x][y]))
            if len(trovati) == 1:
                if scelta == 3:
                    risposta = input("Vuoi cancellare? (si/no): ")
                    if risposta == "si":
                        indice = trovati[0][0]
                        delete_query =("Delete from "+tabella+
                                        " where id= %s")
                        cursor.execute(delete_query, indice)
                        print ("Cancellazione eseguita con successo")
                    else:
                        print ("Cancellazione annullata")
                if scelta == 2:
                    risposta = input("Vuoi modificare? (si/no): ")
                    if risposta == "si":
                        indice = trovati[0][0]
                        nome = input("Inserire nuovo nome: ")
                        cognome = input("Inserire nuovo cognome: ")
                        update_query = ("update "+tabella+
                                        " set nome= '"+nome+"', cognome= '"+cognome+"' where id= %s")
                        cursor.execute(update_query, indice)
                        #oppure fare un for che cambi nome e cognome
                        print ("Modifica eseguita con successo")
                    else:
                        print ("Modifica annullata")
            elif len(trovati) > 1:
                if scelta == 3:
                    risposta = input("Vuoi cancellare? (si/no): ")
                    if risposta == "si":
                        idDaCancellare = int(input("Inserire l'id da cancellare: "))
                        for x in range (len(trovati)):
                            if idDaCancellare == trovati[x][0]:
                                trovato = True
                                break
                        if trovato:
                            indice = idDaCancellare
                            delete_query =("Delete from "+tabella+
                                           " where id= %s")
                            cursor.execute(delete_query, indice)
                            print ("Cancellazione eseguita con successo")
                        else:
                            print ("Id non trovato")
                    else:
                        print ("Cancellazione annullata")
                if scelta == 2:
                    risposta = input("Vuoi modificare? (si/no): ")
                    if risposta == "si":
                        idDaCambiare = int(input("Inserire l'id da cambiare: "))
                        for x in range (len(trovati)):
                            if idDaCambiare == trovati[x][0]:
                                trovato = True
                                break
                        if trovato:
                            indice = idDaCambiare
                            nome = input("Inserire nuovo nome: ")
                            cognome = input("Inserire nuovo cognome: ")
                            update_query = ("update "+tabella+" set nome= '"+nome+
                                            "', cognome= '"+cognome+"' where id= %s")
                            cursor.execute(update_query, indice)
                            #oppure fare un for che cambi nome e cognome 
                            print ("Modifica eseguita con successo")
                        else:
                            print ("Id non trovato")    
                    else:
                        print ("Modifica annullata")   
            else:
                print ("Nome e cognome non trovati")       
        else:  
            print ("Errore: inserire un numero da 1 a 2")
        trovato = False
        indice = 0
        trovati = []
        connection.commit()
        continua()
    if scelta == 5:
        colonna = input("Inserire il nome della colonna: ")
        cursor.execute("SELECT * FROM "+colonna)
        rows = cursor.fetchall()
        for x in range (len(rows)):
            for y in range (len(rows[x])):
                print (etichette[y]+str(rows[x][y]))
        continua()
    elif scelta == 6:
        print ("Fine programma")
        cursor.close()
        connection.close()