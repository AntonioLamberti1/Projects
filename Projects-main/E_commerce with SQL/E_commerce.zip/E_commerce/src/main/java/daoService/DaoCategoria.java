package daoService;

import static connector.Connector.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Categoria;

public class DaoCategoria implements IDaoService<Categoria> {
	@Override
	public boolean insert(Categoria c) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		String comandoSQL = "insert into categorie (nomeC)" + "values(?)";
		try {
			ps = conn.prepareStatement(comandoSQL);
			ps.setString(1, c.getNomeCategoria());
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();

			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	};

	@Override
	public Categoria findById(int id) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Categoria c = null;
		String comandoSQL = "select * from categorie where id=?";
		try {
			ps = conn.prepareStatement(comandoSQL);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			if (rs.next()) {
				c = new Categoria();
				c.setId(rs.getInt("id"));
				c.setNomeCategoria(rs.getString("nomeC"));

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				return null;
			}
		}
		return c;

	};

	@Override
	public List<Categoria> findAll() {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Categoria c = null;
		List<Categoria> listaCategorie = new ArrayList<>();
		String comandoSQL = "select * from categorie";
		try {
			ps = conn.prepareStatement(comandoSQL);
			rs = ps.executeQuery();
			while (rs.next()) {
				c = new Categoria();
				c.setId(rs.getInt("id"));
				c.setNomeCategoria(rs.getString("nomeC"));
				listaCategorie.add(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return listaCategorie;

	};

	@Override
	public boolean update(Categoria modificata) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		String comandoSQL = "update categorie set nomeC=? where id = ?";
		try {
			ps = conn.prepareStatement(comandoSQL);
			ps.setInt(2, modificata.getId());
			ps.setString(1, modificata.getNomeCategoria());
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();

			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	};

	@Override
	public boolean delete(int id) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		String comandoSQL = "delete from categorie where id = ?";
		try {
			ps = conn.prepareStatement(comandoSQL);
			ps.setInt(1, id);
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();

			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	};
	
	public boolean insertDefault() {
		Connection conn= getInstance().openConnection();
		PreparedStatement ps= null;
		ResultSet rs= null;
		String comandoSQL = "select id from categorie";
		try {
			ps= conn.prepareStatement(comandoSQL);
			rs=ps.executeQuery();
			if(!rs.next()) {
				ps.close();
				comandoSQL = "insert into categorie (nomeC) values('Elettronica'),('Periferiche')";
				ps = conn.prepareStatement(comandoSQL);
				ps.execute();
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				rs.close();
				conn.close();
				
			}catch(SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}
}












