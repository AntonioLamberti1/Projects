package controller;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.DaoServiceRuoli;
import model.Ruolo;


@WebServlet("/RuoloServlet")
public class RuoloServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	@Override
	public void init(ServletConfig config) throws ServletException {
		
		DaoServiceRuoli daoRuolo = new DaoServiceRuoli();
		ServletContext application = config.getServletContext();
		application.setAttribute("dao_Ruolo", daoRuolo); 
		
//		daoRuolo.inserimentoFabbrica();
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String sceltaStringa = request.getParameter("scelta");
		if(sceltaStringa == null) {
			request.getRequestDispatcher("index.html").forward(request, response);
		}
		else {
			DaoServiceRuoli daoRuolo = (DaoServiceRuoli)request.getServletContext().getAttribute("dao_Ruolo");			
			int sceltaInt = Integer.parseInt(sceltaStringa);
			switch(sceltaInt) {
			case 1:
				request.setAttribute("lista", daoRuolo.lettura());
				request.getRequestDispatcher("visualizzaRuoli.jsp").forward(request, response);
				break;
			case 2:
				Ruolo r = daoRuolo.letturaSingola(Integer.parseInt(request.getParameter("id")));
				request.setAttribute("r", r);
				request.getRequestDispatcher("modificaRuoli.jsp").forward(request, response);
				break;
			case 3:
				daoRuolo.elimina(Integer.parseInt(request.getParameter("id")));
				response.sendRedirect("RuoloServlet?scelta=1");
				break;
			}
		}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Ruolo r = new Ruolo();
		DaoServiceRuoli daoRuolo = (DaoServiceRuoli)request.getServletContext().getAttribute("dao_Ruolo");
		boolean successo = false;
		int scelta = Integer.parseInt(request.getParameter("scelta"));
		r.setNome(request.getParameter("nome"));
		r.setDescrizione(request.getParameter("descrizione"));
		switch(scelta) {
		case 4:
			successo = daoRuolo.inserimento(r);
			response.sendRedirect("RuoloServlet?scelta=1");
			break;
		case 5:
			r.setId(Integer.parseInt(request.getParameter("id")));
			successo = daoRuolo.modifica(r);
			response.sendRedirect("RuoloServlet?scelta=1");
			break;
		}
	}
	

}
