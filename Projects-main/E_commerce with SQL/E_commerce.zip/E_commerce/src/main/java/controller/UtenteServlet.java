package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import daoService.DaoUtente;
import model.Utente;

@WebServlet("/UtenteServlet")
public class UtenteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	DaoUtente daoU = new DaoUtente();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		 
		int scelta = Integer.parseInt(request.getParameter("scelta"));
		switch (scelta) {
		case 1:// lettura singola
			Utente u = daoU.findById(Integer.parseInt(request.getParameter("id")));
			request.setAttribute("utente", u);
			request.getRequestDispatcher("modificaUtente.jsp").forward(request, response);;
			break;
		case 2:// lettura totale
			request.setAttribute("listaUtenti", daoU.findAll());
			request.getRequestDispatcher("visualizzaUtenti.jsp").forward(request, response);
			break;
		case 3:// eliminazione
			daoU.delete(Integer.parseInt(request.getParameter("id")));
			response.sendRedirect("UtenteServlet?scelta=2");
			break;
		case 6:
			request.getRequestDispatcher("InserireUtente.jsp").forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int scelta = Integer.parseInt(request.getParameter("scelta"));
		Utente u = new Utente();
		u.setNome(request.getParameter("nome"));
		u.setCognome(request.getParameter("cognome"));
		u.setCodiceFiscale(request.getParameter("codice_fiscale"));
		u.setCap(request.getParameter("cap"));
		u.setProvincia(request.getParameter("provincia"));
		u.setCitta(request.getParameter("citta"));
		u.setVia(request.getParameter("via"));
		u.setNumeroCivico(Integer.parseInt(request.getParameter("numero_civico")));
		switch (scelta) {
		case 4:// inserimento
			daoU.insert(u);
			response.sendRedirect("UtenteServlet?scelta=2");
			break;
		case 5://  modifica
			u.setId(Integer.parseInt(request.getParameter("id")));
			daoU.update(u);
			response.sendRedirect("UtenteServlet?scelta=2");
			break;
		}

	}

}
