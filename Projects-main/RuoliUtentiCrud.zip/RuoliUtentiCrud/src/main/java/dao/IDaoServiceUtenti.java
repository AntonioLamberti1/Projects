package dao;

import java.util.List;

import model.Utente;

public interface IDaoServiceUtenti {

	public boolean inserimento(Utente u);
	public Utente letturaSingola(int id);
	public List<Utente> lettura();
	public boolean modifica(Utente u);
	public boolean elimina(int id);
	public void inserimentoFabbrica();
}
