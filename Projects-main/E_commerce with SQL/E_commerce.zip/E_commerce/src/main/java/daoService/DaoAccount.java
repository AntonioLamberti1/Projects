package daoService;

import static connector.Connector.getInstance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Account;

public class DaoAccount implements IDaoService<Account>{
	@Override
	public boolean insert(Account a) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		String commandSQL = "Insert into accounts(email, username, password, id_ruolo) "
				+ "values(?,?,?,3)";
		try {
			ps = conn.prepareStatement(commandSQL);
			ps.setString(1, a.getEmail());
			ps.setString(2, a.getUsername());
			ps.setString(3, a.getPassword());
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}

	@Override
	public Account findById(int id) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Account a = null;
		String commandSQL = "select * from accounts where id=?";
		try {
			ps = conn.prepareStatement(commandSQL);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			if (rs.next()) {
				a = new Account();
				a.setId(rs.getInt("id"));
				a.setEmail(rs.getString("email"));
				a.setUsername(rs.getString("username"));
				a.setPassword(rs.getString("password"));
				a.setId_ruolo(rs.getInt("id_ruolo"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return a;
	}

	@Override
	public List<Account> findAll() {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Account a = null;
		List<Account> accounts = new ArrayList<>();
		String commandSQL = "select * from accounts";
		try {
			ps = conn.prepareStatement(commandSQL);
			rs = ps.executeQuery();
			while (rs.next()) {
				a = new Account();
				a.setId(rs.getInt("id"));
				a.setEmail(rs.getString("email"));
				a.setUsername(rs.getString("username"));
				a.setPassword(rs.getString("password"));
				a.setId_ruolo(rs.getInt("id_ruolo"));
				accounts.add(a);
			}
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return accounts;
	}

	@Override
	public boolean update(Account a) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		String commandSQL = "update accounts set email=?, username=?, password=?, "
				+ "id_ruolo=? where id=?";
		try {
			ps = conn.prepareStatement(commandSQL);
			ps.setString(1, a.getEmail());
			ps.setString(2, a.getUsername());
			ps.setString(3, a.getPassword());
			ps.setInt(4, a.getId_ruolo());
			ps.setInt(5, a.getId());
			ps.execute();
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}

	@Override
	public boolean delete(int id) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		String commandSQL = "delete from accounts where id = ? ";
		try {
			ps = conn.prepareStatement(commandSQL);
			ps.setInt(1, id);
			ps.execute();
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}
	
	public boolean insertDefault() {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String commandSQL = "select id from accounts";
		try {
			ps = conn.prepareStatement(commandSQL);
			rs = ps.executeQuery();
			if (!rs.next()) {
				ps.close();
				commandSQL = "insert into accounts(email, username, password, id_ruolo) "
						+ "values ('william@gmail.com','Sindo','Sindo17', 1),"
						+ "('vincenzo@gmail.com','Ozne','Ozne20', 2),"
						+ "('lamberti@gmail.com','Lion','Strength', 2),"
						+ "('manuele@gmail.com','Manu','Ele', 2)";
				ps = conn.prepareStatement(commandSQL);
				ps.execute();
			}
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}
}
