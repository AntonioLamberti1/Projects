package daoService;

import static connector.Connector.getInstance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.DTOAccountRuolo;

public class DaoDTOAccount {
	
	public List<DTOAccountRuolo> findAll(){
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		DTOAccountRuolo dto = null;
		List<DTOAccountRuolo> dtos = new ArrayList<>();
		String commandSQL = "select * from v_accounts_ruoli";
		try {
			ps = conn.prepareStatement(commandSQL);
			rs = ps.executeQuery();
			while (rs.next()) {
				dto = new DTOAccountRuolo();
				dto.setId(rs.getInt("id"));
				dto.setEmail(rs.getString("email"));
				dto.setUsername(rs.getString("username"));
				dto.setNomeRuolo(rs.getString("nome_ruolo"));
				dtos.add(dto);
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return dtos;
	}
}
