package dao;

import java.util.List;

import model.Ruolo;

public interface IDaoServiceRuoli {

	public boolean inserimento(Ruolo r);
	public Ruolo letturaSingola(int id);
	public List<Ruolo> lettura();
	public boolean modifica(Ruolo r);
	public boolean elimina(int id);
	public void inserimentoFabbrica();
}
