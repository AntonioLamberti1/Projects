package controller;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.DaoServiceUtenti;
import model.Utente;
import validation.Validation;


@WebServlet("/UtenteServlet")
public class UtenteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
      

	@Override
	public void init(ServletConfig config) throws ServletException {
		DaoServiceUtenti daoUtente = new DaoServiceUtenti();
		ServletContext application = config.getServletContext();
		application.setAttribute("dao_Utente", daoUtente);
		
//		newDao.inserimentoFabbrica();
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String sceltaStringa = request.getParameter("scelta");
		if(sceltaStringa == null) {
			request.getRequestDispatcher("index.html").forward(request, response);
		}
		else {
			DaoServiceUtenti daoUtente = (DaoServiceUtenti)request.getServletContext().getAttribute("dao_Utente");			
			int sceltaInt = Integer.parseInt(sceltaStringa);
			switch(sceltaInt) {
			
			case 1:
				request.setAttribute("lista", daoUtente.lettura());
				request.getRequestDispatcher("visualizzaUtenti.jsp").forward(request, response);
				break;
				
			case 2:
				Utente u = daoUtente.letturaSingola(Integer.parseInt(request.getParameter("id")));
				request.setAttribute("u", u);
				request.getRequestDispatcher("modificaUtenti.jsp").forward(request, response);
				break;
			case 3:
				daoUtente.elimina(Integer.parseInt(request.getParameter("id")));
				response.sendRedirect("UtenteServlet?scelta=1");
				break;
			}
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String[] erroriCampi = {"","","","","","","",""};
		String risultatoValidazione = null;
		Validation v = new Validation();
		boolean flag = false;
		
		Utente u = new Utente();
		DaoServiceUtenti daoUtente = (DaoServiceUtenti)request.getServletContext().getAttribute("dao_Utente");
		boolean successo = false;
		int scelta = Integer.parseInt(request.getParameter("scelta"));
		u.setUsername(request.getParameter("username"));
		u.setEmail(request.getParameter("email"));
		u.setPassword(request.getParameter("password"));
		u.setNome(request.getParameter("nome"));
		u.setCognome(request.getParameter("cognome"));
		u.setCf(request.getParameter("cf"));
		u.setDataNascita(Date.valueOf(request.getParameter("dataNascita")));
		u.setStipendio(Double.parseDouble(request.getParameter("stipendio")));
		
		risultatoValidazione = v.controlloNonVuoto(u.getUsername(), "L'Username ");
		if(!risultatoValidazione.equals("")) {
			erroriCampi[0] = risultatoValidazione;
			flag = true;
		}
		
		risultatoValidazione = v.controlloEmail(u.getEmail());
		if(!risultatoValidazione.equals("")) {
			erroriCampi[1] = risultatoValidazione;
			flag = true;
		}
		
		risultatoValidazione = v.controlloPassword(u.getPassword(), "La Password ");
		if(!risultatoValidazione.equals("")) {
			erroriCampi[2] = risultatoValidazione;
			flag = true;
		}
		
		risultatoValidazione = v.controlloLettere(u.getNome(), "Il nome ");
		if(!risultatoValidazione.equals("")) {
			erroriCampi[3] = risultatoValidazione;
			flag = true;
		}
		risultatoValidazione = v.controlloLettere(u.getCognome(), "Il cognome ");
		if(!risultatoValidazione.equals("")) {
			erroriCampi[4] = risultatoValidazione;
			flag = true;
		}
		risultatoValidazione = v.controlloCodiceFiscale(u.getCf(), "Il Codice Fiscale ");
		if(!risultatoValidazione.equals("")) {
			erroriCampi[5] = risultatoValidazione;
			flag = true;
		}
		risultatoValidazione = v.controlloData(u.getDataNascita().toString(), "La data di nascita ");
		if(!risultatoValidazione.equals("")) {
			erroriCampi[6] = risultatoValidazione;
			flag = true;
		}
		risultatoValidazione = v.controlloNumericoDouble(Double.toString(u.getStipendio()), "Lo stipendio ");
		if(!risultatoValidazione.equals("")) {
			erroriCampi[7] = risultatoValidazione;
			flag = true;
		}
		
		switch(scelta) {
		case 4:
			if(flag) {
				request.setAttribute("errori", erroriCampi);
				request.getRequestDispatcher("inserimentoUtenti.jsp").forward(request, response);
			}else {
				successo = daoUtente.inserimento(u);
				response.sendRedirect("UtenteServlet?scelta=1");
			}
			break;
		case 5:
			if(flag) {
				request.setAttribute("errori", erroriCampi);
				request.getRequestDispatcher("modificaUtenti.jsp").forward(request, response);
			}else {
				u.setId(Integer.parseInt(request.getParameter("id")));
				successo = daoUtente.modifica(u);
				response.sendRedirect("UtenteServlet?scelta=1");
			}
			break;
		}
		
		
		
	}

}
