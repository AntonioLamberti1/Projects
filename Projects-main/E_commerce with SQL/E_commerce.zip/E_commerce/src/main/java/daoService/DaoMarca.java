package daoService;

import static connector.Connector.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Marca;

public class DaoMarca implements IDaoService<Marca> {
	@Override
	public boolean insert(Marca m) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		String comandoSQL = "insert into marche (nomeM)" + "values(?)";
		try {
			ps = conn.prepareStatement(comandoSQL);
			ps.setString(1, m.getNomeMarca());
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();

			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	};

	@Override
	public Marca findById(int id) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Marca m = null;
		String comandoSQL = "select * from marche where id=?";
		try {
			ps = conn.prepareStatement(comandoSQL);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			if (rs.next()) {
				m = new Marca();
				m.setId(rs.getInt("id"));
				m.setNomeMarca(rs.getString("nomeM"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				return null;
			}
		}
		return m;

	};

	@Override
	public List<Marca> findAll() {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Marca m = null;
		List<Marca> listaMarche = new ArrayList<>();
		String comandoSQL = "select * from marche";
		try {
			ps = conn.prepareStatement(comandoSQL);
			rs = ps.executeQuery();
			while (rs.next()) {
				m = new Marca();
				m.setId(rs.getInt("id"));
				m.setNomeMarca(rs.getString("nomeM"));
				listaMarche.add(m);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return listaMarche;

	};

	@Override
	public boolean update(Marca modificata) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		String comandoSQL = "update marche set nomeM=? where id = ?";
		try {
			ps = conn.prepareStatement(comandoSQL);
			ps.setInt(2, modificata.getId());
			ps.setString(1, modificata.getNomeMarca());
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();

			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	};

	@Override
	public boolean delete(int id) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		String comandoSQL = "delete from marche where id = ?";
		try {
			ps = conn.prepareStatement(comandoSQL);
			ps.setInt(1, id);
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();

			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}
	
	public boolean insertDefault() {
		Connection conn= getInstance().openConnection();
		PreparedStatement ps= null;
		ResultSet rs= null;
		String comandoSQL = "select id from marche";
		try {
			ps= conn.prepareStatement(comandoSQL);
			rs=ps.executeQuery();
			if(!rs.next()) {
				ps.close();
				comandoSQL = "insert into marche (nomeM) values('Nvidia'),('Apple')";
				ps = conn.prepareStatement(comandoSQL);
				ps.execute();
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				ps.close();
				rs.close();
				conn.close();
				
			}catch(SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}

}
