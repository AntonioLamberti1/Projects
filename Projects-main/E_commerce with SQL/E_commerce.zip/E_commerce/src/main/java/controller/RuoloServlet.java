package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import daoService.DaoRuolo;
import model.Ruolo;

@WebServlet("/RuoloServlet")
public class RuoloServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	DaoRuolo daoR = new DaoRuolo();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		 
		int scelta = Integer.parseInt(request.getParameter("scelta"));
		switch (scelta) {
		case 1:// lettura singola
			Ruolo r = daoR.findById(Integer.parseInt(request.getParameter("id")));
			request.setAttribute("ruolo", r);
			request.getRequestDispatcher("modificaRuolo.jsp").forward(request, response);;
			break;
		case 2:// lettura totale
			request.setAttribute("listaRuoli", daoR.findAll());
			request.getRequestDispatcher("visualizzaRuoli.jsp").forward(request, response);
			break;
		case 3:// eliminazione
			daoR.delete(Integer.parseInt(request.getParameter("id")));
			response.sendRedirect("RuoloServlet?scelta=2");
			break;
		case 6:
			request.setAttribute("listaRuoli", daoR.findAll());
			request.getRequestDispatcher("InserireRuoli.jsp").forward(request, response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int scelta = Integer.parseInt(request.getParameter("scelta"));
		Ruolo r = new Ruolo();
		r.setNomeRuolo(request.getParameter("nome_ruolo"));
		switch (scelta) {
		case 4:// inserimento
			daoR.insert(r);
			response.sendRedirect("RuoloServlet?scelta=2");
			break;
		case 5://  modifica
			r.setId(Integer.parseInt(request.getParameter("id")));
			daoR.update(r);
			response.sendRedirect("RuoloServlet?scelta=2");
			break;
		}

	}

}
