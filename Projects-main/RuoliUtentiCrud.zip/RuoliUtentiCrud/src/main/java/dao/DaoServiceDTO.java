package dao;

import static connettore.Connettore.getInstance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.DTO;

public class DaoServiceDTO implements IDaoServiceDTO{

	@Override
	public List<DTO> letturaView() {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		DTO dto = null;
		List<DTO> view = new ArrayList<DTO>();
		String comandoSQL = "select * from v_ruoli_utente order by id";
		try {
			ps = conn.prepareStatement(comandoSQL);
			rs = ps.executeQuery();
			while(rs.next()) {
				dto = new DTO();
				dto.setId(rs.getInt("id"));
				dto.setUsername(rs.getString("username"));
				dto.setEmail(rs.getString("email"));
				dto.setNome(rs.getString("nome"));
				dto.setCognome(rs.getString("cognome"));
				dto.setCf(rs.getString("cf"));
				dto.setDataNascita(rs.getDate("dataNascita"));
				dto.setStipendio(rs.getDouble("stipendio"));
				dto.setNomeRuolo(rs.getString("nomeRuolo"));
				dto.setDescrizione(rs.getString("descrizione"));
				view.add(dto);
				}
			} catch(SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					ps.close();
					conn.close();
				} catch(SQLException e) {
					e.printStackTrace();
					return null;
				}
			}
		return view;
	}

}
