package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import static connettore.Connettore.*;
import model.Utente;

public class DaoServiceUtenti implements IDaoServiceUtenti {

	@Override
	public boolean inserimento(Utente u) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		String comandoSQL = "insert into utenti (username,email,password,nome,cognome,cf,dataNascita,stipendio,id_ruolo)"
				+ "values (?,?,?,?,?,?,?,?,2)";
		try {
			ps = conn.prepareStatement(comandoSQL);
			ps.setString(1, u.getUsername());
			ps.setString(2, u.getEmail());
			ps.setString(3, u.getPassword());
			ps.setString(4, u.getNome());
			ps.setString(5, u.getCognome());
			ps.setString(6, u.getCf());
			ps.setDate(7, u.getDataNascita());
			ps.setDouble(8, u.getStipendio());
			ps.execute();
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		} 
		return true;
	}

	@Override
	public Utente letturaSingola(int id) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Utente u = null;
		String comandoSQL = "select * from utenti where id=?";
		try {
			ps = conn.prepareStatement(comandoSQL);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			if(rs.next()) {
				u = new Utente();
				u.setId(rs.getInt("id"));
				u.setUsername(rs.getString("username"));
				u.setEmail(rs.getString("email"));
				u.setNome(rs.getString("nome"));
				u.setCognome(rs.getString("cognome"));
				u.setCf(rs.getString("cf"));
				u.setDataNascita(rs.getDate("dataNascita"));
				u.setStipendio(rs.getDouble("stipendio"));
			}
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch(SQLException e) {
				e.printStackTrace();
				return null;
			}
		}
		return u;
	}

	@Override
	public List<Utente> lettura() {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Utente u = null;
		List<Utente> utenti = new ArrayList<Utente>();
		String comandoSQL = "select * from utenti";
		try {
			ps = conn.prepareStatement(comandoSQL);
			rs = ps.executeQuery();
			while(rs.next()) {
				u = new Utente();
				u.setId(rs.getInt("id"));
				u.setUsername(rs.getString("username"));
				u.setEmail(rs.getString("email"));
				u.setNome(rs.getString("nome"));
				u.setCognome(rs.getString("cognome"));
				u.setCf(rs.getString("cf"));
				u.setDataNascita(rs.getDate("dataNascita"));
				u.setStipendio(rs.getDouble("stipendio"));
				utenti.add(u);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch(SQLException e) {
				e.printStackTrace();
				return null;
			}
		}
		return utenti;
	}

	@Override
	public boolean modifica(Utente u) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		String comandoSQL = "update utenti " +
				"set username=?,email=?,password=?,nome=?,cognome=?,cf=?,dataNascita=?,stipendio=? where id=?";
		try {
			ps = conn.prepareStatement(comandoSQL);
			ps.setString(1, u.getUsername());
			ps.setString(2, u.getEmail());
			ps.setString(3, u.getPassword());
			ps.setString(4, u.getNome());
			ps.setString(5, u.getCognome());
			ps.setString(6, u.getCf());
			ps.setDate(7, u.getDataNascita());
			ps.setDouble(8, u.getStipendio());
			ps.setInt(9, u.getId());
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch(SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		return true;
	}

	@Override
	public boolean elimina(int id) {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		String comandoSQL = "delete from utenti where id=?";
		try {
			ps = conn.prepareStatement(comandoSQL);
			ps.setInt(1, id);
			ps.execute();
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch(SQLException e) {
				e.printStackTrace();
				return false;
			} 
		}
		return true;
	}

	@Override
	public void inserimentoFabbrica() {
		Connection conn = getInstance().openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
//		String comandoSQL = "INSERT INTO utenti (username,password)"
//				+ "SELECT 'admin','admin'" 
//				+ "WHERE NOT EXISTS (SELECT username FROM utenti WHERE username = 'admin')";
		String comandoSQL = "select username from utenti";
		try {
			ps = conn.prepareStatement(comandoSQL);
			rs = ps.executeQuery();
			if(!rs.next()) {
				ps.close();
				comandoSQL = "insert into utenti (username,email,password,nome,cognome,cf,id_ruolo) " 
									+ "values ('admin','','admin','','','',1)";
				ps = conn.prepareStatement(comandoSQL);
				ps.execute();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch(SQLException e) {
				e.printStackTrace();
			}
		}
	}
		

	
	
}
