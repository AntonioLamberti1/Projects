package connettore;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class Connettore {

	private final String PATHDRIVER = "org.postgresql.Driver";
	private final String URLDB = "jdbc:postgresql://localhost:5432/ruoli_utenti";
	private final String USERDBMS = "postgres";
	private final String PASSWDBMS = "admin";
	
	private Connection conn = null;
	private static Connettore instance = null;
	
	public synchronized Connection openConnection() {
		try {
			Class.forName(PATHDRIVER); 
			conn = DriverManager.getConnection(URLDB, USERDBMS, PASSWDBMS);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}
	
	private Connettore() {}
	
	public static Connettore getInstance() {
		if(instance == null) {
			instance = new Connettore();
		}
		return instance;
	}
}
